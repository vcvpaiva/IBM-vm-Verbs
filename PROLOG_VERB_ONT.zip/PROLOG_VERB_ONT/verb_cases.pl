/*

AUTHOR: Prolog conversion by Arun Majumdar, VivoMind Intelligence Inc; 
From sources provided by IBM to CSLI and released into the PUBLIC DOMAIN
LICENSE:  PUBLIC DOMAIN 
- this license means "Public Domain, Open Source" so you can do with as you will,
for academic or commercial use.

Due Credit is appreciated, though, not required.


*/


verb_case(*).
verb_case( (abstract) ).
verb_case( (action) ).
verb_case( (addressee) ).
verb_case( (after) ).
verb_case( (against) ).
verb_case( (agnt) ).
verb_case( (animate) ).
verb_case( (ascribed) ).
verb_case( (bodypart) ).
verb_case( (collective) ).
verb_case( (dest) ).
verb_case( (device) ).
verb_case( (efct) ).
verb_case( (efnt) ).
verb_case( (experienced) ).
verb_case( (expr) ).
verb_case( (food) ).
verb_case( (form) ).
verb_case( (from) ).
verb_case( (goal) ).
verb_case( (image) ).
verb_case( (info) ).
verb_case( (inst) ).
verb_case( (liquid) ).
verb_case( (loc) ).
verb_case( (location) ).
verb_case( (matr) ).
verb_case( (med) ).
verb_case( (money) ).
verb_case( (moved) ).
verb_case( (notheta) ).
verb_case( (orgn) ).
verb_case( (path) ).
verb_case( (physobj) ).
verb_case( (pp) ).
verb_case( (process) ).
verb_case( (ptnt) ).
verb_case( (rcpt) ).
verb_case( (rslt) ).
verb_case( (said) ).
verb_case( (scomp) ).
verb_case( (sentient) ).
verb_case( (sound) ).
verb_case( (srce) ).
verb_case( (state) ).
verb_case( (subst) ).
verb_case( (swh) ).
verb_case( (szentient) ).
verb_case( (telc) ).
verb_case( (thme) ).
verb_case( (time) ).
verb_case( (value) ).
verb_case( (vehicle) ).
verb_case( (vpinf) ).

