/*

AUTHOR: Prolog conversion by Arun Majumdar, VivoMind Intelligence Inc; 
From sources provided by IBM to CSLI and released into the PUBLIC DOMAIN
LICENSE:  PUBLIC DOMAIN 
- this license means "Public Domain, Open Source" so you can do with as you will,
for academic or commercial use.

Due Credit is appreciated, though, not required.


*/


prep(*).
prep( (about) ).
prep( (as) ).
prep( (at) ).
prep( (for) ).
prep( (in) ).
prep( (into) ).
prep( (it) ).
prep( (of) ).
prep( (off) ).
prep( (on) ).
prep( (out) ).
prep( (over) ).
prep( (that) ).
prep( (through) ).
prep( (to) ).
prep( (towards) ).
prep( (with) ).

