/*

AUTHOR: Prolog conversion by Arun Majumdar, VivoMind Intelligence Inc; 
From sources provided by IBM to CSLI and released into the PUBLIC DOMAIN
LICENSE:  PUBLIC DOMAIN 
- this license means "Public Domain, Open Source" so you can do with as you will,
for academic or commercial use.

Due Credit is appreciated, though, not required.


*/


:- [csli_verb].					% CURRENTLY INDEXED VERBS 
:- [levin_verbs].				% VERB TO SEMANTIC CLASSES
:- [csli_senses].				% SEMANTIC CLASS TO WORDNET SENSES AND VERBS 
:- [csli_templates].				% SEMANTIC TEMPLATES
:- [csli_ClassTemplateLink].			% LINKS FROM LEV TO TEMPLATE 
:- [csli_SenseExcludedTemplate].		% MISSING VERBS 
:- [csli_SensesAdditionalTemplates].		% LINKAGES - ASSOCIATIVE SUBSETS 
:- [verbs_excluded].				% CURRENTLY MISSING VERBS 
:- [verb_cases].				% VERB CASES
:- [verb_preps].				% VERB PREPOSITIONS
