/*


AUTHOR: Prolog conversion by Arun Majumdar, VivoMind Intelligence Inc; 
From sources provided by IBM to CSLI and released into the PUBLIC DOMAIN
LICENSE:  PUBLIC DOMAIN 
- this license means "Public Domain, Open Source" so you can do with as you will,
for academic or commercial use.

Due Credit is appreciated, though, not required.

*/

%        LEVIN	WORDNET_SENSE		   VERB
%        =====  =============		==========   
classes('10.1',	['0','10'],		['Remove']).
classes('10.2',	['1','10'],		['Banish','verbs']).
classes('10.3',	['1','10'],		['Clear','verbs']).
classes('10.4.1',['1','10'],		['Manner','subclass']).
classes('10.4.2',['1','10'],		['Instrument','subclass']).
classes('10.5',	['1','10'],		['Verbs','of','possessional','deprivation',':','Steal','verbs']).
classes('10.6',	['1','10'],		['verbs','of','possessional','deprivation']).
classes('10.7',	['1','10'],		['Pit','verbs']).
classes('10.8',	['1','10'],		['Debone','verbs','comment_1996_7_9','0',':','0',':','0','Diane']).
classes('10.9',	['1','10'],		['Mine','verbs','comment_1996_7_9','0',':','0',':','0','Diane']).
classes('11.1',	['1','11'],		['Send','I','assume','that','the','dative','alternation','only','happens','with','human','recipients','.']).
classes('11.2',	['1','11'],		['Slide','these','verbs','all','also','occur','in','51.3.1','so','probably','need','to','assign','them','to','a','merged','class','.','Transitive','use','only','specified','here']).
classes('11.3',	['1','11'],		['Bring','and','take','comment_1996_7_9','0',':','0',':','0','Diane']).
classes('11.4',	['1','11'],		['Carry']).
classes('11.5',	['1','11'],		['Drive']).
classes('12',	['1','12'],		['Verbs','of','exerting','force',':','Push','Pull','verbs']).
classes('13.1',	['1','13'],		['Give','verbs','comment_1996_7_9','0',':','0',':','0','Diane']).
classes('13.2',	['1','13'],		['Contribute']).
classes('13.3',	['1','13'],		['Verbs','of','Future','Having']).
classes('13.4.1',['1','13'],		['Verbs','of','Fulfilling']).
classes('13.4.2',['1','13'],		['Equip']).
classes('13.5.1',['1','13'],		['Get','verbs','Most','verbs','in','this','class','allow','PP','(','from',')','but','not','all']).
classes('13.5.2',['1','13'],		['obtain','verbs','NP','NP','(;)','NP','NP','PP','(','from',')']).
classes('13.6',	['1','13'],		['verbs','of','exchange']).
classes('13.7',	['1','13'],		['Berry','verbs','these','verbs','take','almost','exclusively','Ving','comment_1996_7_9','0',':','0',':','0','Diane']).
classes('14',	['1','14'],		['Learn','verbs','comment_1996_7_9','0',':','0',':','0','Diane']).
classes('15.1',	['1','15'],		['Hold']).
classes('15.2',	['1','15'],		['Keep','The','location','slot','is','omitted','because','it','behaves','straightforwardly','as','an','adjunct','(','e.g.no','restriction','on','locational','PPs','which','can','occur','not','obligatory',')']).
classes('16',	['1','16'],		['Verbs','of','concealment','comment_1996_7_30','0',':','0',':','0','Diane']).
classes('17.1',	['1','17'],		['Throw','verbs']).
classes('17.2',	['1','17'],		['Pelt','verbs','comment_1996_7_26','0',':','0',':','0','Diane']).
classes('18.1',	['1','18'],		['Hit']).
classes('18.2',	['1','18'],		['Swat','verbs','comment_1996_7_30','0',':','0',':','0','Diane']).
classes('18.3',	['1','18'],		['Spank','verbs','comment_1996_7_30','0',':','0',':','0','Diane']).
classes('18.4',	['1','18'],		['Non','-','agentive','verbs','of','contact','by','impact']).
classes('19',	['1','19'],		['poke','verbs']).
classes('20',	['1'],			['Touch']).
classes('21.1',	['1','21'],		['Cut','verbs','comment_1996_7_25','0',':','0',':','0','Diane']).
classes('21.2',	['1','21'],		['Carve']).
classes('22.1',	['1','22'],		['Mix','verbs','NP','NP','PP','(','with',')','NP','NP','reciprocal','alt']).
classes('22.2',	['1','22'],		['Amalgamate','templates','do','not','cover','inchoative','use','because','not','found','with','confuse','-','class','should','be','split','.','Th','-','role','assignment','not','certain']).
classes('22.3',	['1','22'],		['Shake']).
classes('22.4',	['1','22'],		['Tape','These','verbs','undergo','the','middle','alternation','but','I','have','not','specified','that','in','the','templates']).
classes('22.5',	['1','22'],		['Cling','verbs','comment_1996_9_6','0',':','0',':','0','Diane']).
classes('23.1',	['1','23'],		['Separate','verbs']).
classes('23.2',	['1','23'],		['Split','verbs','I','have','given','this','class','PP','(','off','of',')','though','I','am','uncertain','of','the','syn','status','of','off','of','comment_1996_7_12','0',':','0',':','0','Diane']).
classes('23.3',	['1','23'],		['Disassemble','verbs','comment_1996_7_10','0',':','0',':','0','Diane']).
classes('23.4',	['1','23'],		['Differ','verbs']).
classes('24',	['1','24'],		['Verbs','of','coloring']).
classes('25.1',	['1','25'],		['Verbs','of','Image','Impression']).
classes('25.2',	['1','25'],		['scribble','verbs','eg','write','draw','paint','type']).
classes('25.3',	['1','25'],		['Illustrate','verbs','comment_1996_8_16','0',':','0',':','0','Diane']).
classes('25.4',	['1','25'],		['transcribe','verbs','comment_1996_7_31','0',':','0',':','0','Diane']).
classes('26.1',	['1','26'],		['Build','I','am','assuming','that','the','source','PP','(','e.g.out','of','a','piece','of','wood',')','is','an','adjunct','rather','than','an','argument']).
classes('26.2',	['1','26'],		['Grow','verbs']).
classes('26.3',	['1','26'],		['Verbs','of','Preparing']).
classes('26.4',	['1','26'],		['Create','verbs']).
classes('26.5',	['1','26'],		['Knead','Some','verbs','require','the','PPinto','but','most','do','not','so','I','have','specified','it','on','the','class']).
classes('26.6',	['1','26'],		['Turn','Some','of','these','verbs','are','possible','in','a','simple','transitive','in','the','causative','use','-','the','alchemist','transmuted','lead','but','others','seem','to','require','the','goal','-','I','have','left','the','simple','transitive','out','of','the','class','spec','.','I','have','also','omitted','the','inchoative','because','I','am','not','sure','it','actually','applies','to','more','than','half','of','these','verbs']).
classes('26.7',	['1','26'],		['Performance','verbs','I','have','left','the','dative_benefactive','for','the','individual','verbs']).
classes('27',	['1','27'],		['Engender','verbs','Levin','states','that','these','verbs','typically','take','abstract','subj','and','obj','.','I','have','allowed','*','subj','and','obj','because','this','seems','more','likely','-','trees','yield','fruit','comment_1996_7_29','0',':','0',':','0','Diane']).
classes('28',	['1','28'],		['Calve','verbs','this','class','so','restricted','that','it','seem','of','little','value','comment_1996_8_21','0',':','0',':','0','Diane']).
classes('29.1',	['0','29'],		['Appoint','verbs','differ','from','characterize','verbs','in','that','allow','double','object','construction']).
classes('29.2',	['1','29'],		['Characterize']).
classes('29.3',	['1','29'],		['Dub','verbs','eg','christen','brand','call','label']).
classes('29.4',	['0','29'],		['Declare','verbs','This','class','take','NP','NP','NP','(;)','NP','NP','Vinf']).
classes('29.5',	['1','29'],		['Conjecture','verbs','NP','NP','to','be','(;)','NP','SComp','(','that',')']).
classes('29.6',	['1','29'],		['Masquerade','verbs','comment_1996_7_26','0',':','0',':','0','Diane']).
classes('29.7',	['1','29'],		['Orphan','verbs','comment_1996_9_16','0',':','0',':','0','Diane']).
classes('29.8',	['1','29'],		['Captain','verbs','comment_1996_8_16','0',':','0',':','0','Diane']).
classes('30.1',	['1','30'],		['See','verbs','comment_1996_7_31','0',':','0',':','0','Diane']).
classes('30.2',	['1','30'],		['Sight','verbs']).
classes('30.3',	['1','30'],		['Peer','verbs','comment_1996_7_26','0',':','0',':','0','Diane']).
classes('30.4',	['1','30'],		['Stimulus','subject','perception','verbs','comment_1996_8_23','0',':','0',':','0','Diane']).
classes('31.1',	['1','31'],		['Amuse']).
classes('31.2',	['1','31'],		['Admire']).
classes('31.3',	['1','31'],		['Marvel']).
classes('31.4',	['1','31'],		['Appeal']).
classes('32.1',	['1','32'],		['Want']).
classes('32.2',	['1','32'],		['Long','takes','PP','stative']).
classes('33',	['1','33'],		['Judgement']).
classes('34',	['1','34'],		['Verbs','of','assessment','comment_1996_7_26','0',':','0',':','0','Diane']).
classes('35.1',	['1','35'],		['Hunt','verbs','comment_1996_7_9','0',':','0',':','0','Diane']).
classes('35.2',	['1','35'],		['Search','verbs','comment_1996_7_9','0',':','0',':','0','Diane']).
classes('35.3',	['1','35'],		['Stalk']).
classes('35.4',	['1','35'],		['Investigate','verbs','NP','NP','PP','(','for',')']).
classes('35.5',	['1','35'],		['Rummage','verbs','this','whole','class','seems','weak','to','me','comment_1996_8_22','0',':','0',':','0','Diane']).
classes('35.6',	['1','35'],		['Ferret','verbs','comment_1996_9_13','0',':','0',':','0','Diane']).
classes('36.1',	['1','36'],		['correspond','verbs','NP','PP','(','with',')','(;)','NP']).
classes('36.2',	['1','36'],		['Marry','verbs']).
classes('36.3',	['1','36'],		['Meet','verbs']).
classes('37.1',	['1','37'],		['verbs','of','transfer','of','a','message','NP','NP','NP',';','NP','NP',';','NP','WHS',';']).
classes('37.3',	['1','37'],		['verbs','of','manner','of','speaking']).
classes('37.4',	['1','37'],		['Verbs','of','instrument','of','communication','These','verbs','take','the','dative','alternation','and','describe','exchange','of','information','via','instrument','.','Levins','memebers','include','eg.fax','modem','telex','email','etc','Phone','and','telephone','are','also','included','but','I','do','not','accept','that','they','take','the','dative','alternation','and','can','take','info','as','direct','object','*','Kim','phoned','John','the','news','*','Kim','phoned','the','news','to','John'.'I','would','like','to','separate','Phone','from','this','class','but','maybe','it','is','AmEng','?']).
classes('37.5',	['1','37'],		['Talk','verbs']).
classes('37.6',	['1','37'],		['chitchat','verbs']).
classes('37.7',	['1','37'],		['Say']).
classes('37.8',	['1','37'],		['complain','verbs']).
classes('37.9',	['1','37'],		['Advise','P','in','Said','phrase','is','frequently','against','but','could','be','expressed','in','other','ways','.','Obligatory','but','not','verb','specific','so','left','underspecified']).
classes('38',	['1'],			['verbs','of','sounds','made','by','animals','humans','can','make','some','of','these','noises','too']).
classes('39.1',	['1','39'],		['Eat','verbs','comment_1996_9_11','0',':','0',':','0','Diane']).
classes('39.2',	['1','39'],		['Chew','verbs','comment_1996_7_10','0',':','0',':','0','Diane']).
classes('39.3',	['1','39'],		['Gobble']).
classes('39.5',	['1','39'],		['Dine','verbs','comment_1996_8_16','0',':','0',':','0','Diane']).
classes('39.6',	['1','39'],		['Gorge','verbs','comment_1996_7_10','0',':','0',':','0','Diane']).
classes('39.7',	['1','39'],		['Verbs','of','feeding','comment_1996_7_10','0',':','0',':','0','Diane']).
classes('40.1.1',['1','40'],		['Hiccup','verbs','comment_1996_7_11','0',':','0',':','0','Diane']).
classes('40.1.2',['0','40'],		['Breathe','verbs','comment_1996_7_10','0',':','0',':','0','Diane']).
classes('40.2',	['1','40'],		['verbs','of','non','-','verbal','expression']).
classes('40.3.1',['1','40'],		['Wink','I','have','omitted','the','reaction','object','possibility']).
classes('40.3.2',['1','40'],		['Crane','The','at','PP','is','probably','best','treated','as','an','adjunct']).
classes('40.3.3',['1','40'],		['Curtsey','verbs','comment_1996_7_30','0',':','0',':','0','Diane']).
classes('40.4',	['1','40'],		['Snooze','verbs','comment_1996_7_31','0',':','0',':','0','Diane']).
classes('40.5',	['1','40'],		['flinch','verbs']).
classes('40.6',	['1','40'],		['Verbs','of','Body','-','Internal','States','of','Existence']).
classes('40.7',	['1','40'],		['Suffocate','verbs','comment_1996_7_29','0',':','0',':','0','Diane']).
classes('40.8.1',['1','40'],		['Pain','trans','or','intrans','bodily','state','-','not','really','sure','whether','Levin','thinks','these','all','have','trans','use','(','they','do','not',')']).
classes('40.8.2',['1','40'],		['Tingle']).
classes('40.8.3',['1','40'],		['hurt','verbs','specifically','for','the','uses','where','one','hurts','oneself']).
classes('40.8.4',['1','40'],		['Verbs','of','change','of','bodily','state','comment_1996_7_29','0',':','0',':','0','Diane']).
classes('41.1.1',['0','41'],		['Dress','verbs']).
classes('41.1.2',['1','41'],		['Groom','verbs','AAC',':','tthis','class','seems','fairly','useless','-','possibly','merge','later','?','comment_1996_7_30','0',':','0',':','0','Diane']).
classes('41.2.1',['1','41'],		['Floss','verbs']).
classes('41.2.2',['1','41'],		['Braid']).
classes('41.3.1',['1','41'],		['Simple','verbs','of','dressing','comment_1996_7_29','0',':','0',':','0','Diane']).
classes('42.1',	['1','42'],		['Murder','verbs','comment_1996_7_9','0',':','0',':','0','Diane']).
classes('42.2',	['1','42'],		['poison','verbs']).
classes('43.1',	['1','43'],		['Verbs','of','light','emission','comment_1996_7_29','0',':','0',':','0','Diane']).
classes('43.2',	['1','43'],		['Verbs','of','Sound','Emission','I','am','ignoring','the','locative','alternation','locative','inversion','and','there','insertion','.','I','do','not','t','think','most','verbs','have','the','causative','use','so','I','have','left','that','for','individual','specification','.','Similarly','the','chimed','the','hour','use','.','Directional','stuff','is','more','frequent','but','quite','marked','usually','so','I','have','omitted','it','.','DN','-','I','have','changed','the','sem','to','physobj','.']).
classes('43.3',	['1','43'],		['Verbs','of','smell','emission','comment_1996_7_31','0',':','0',':','0','Diane']).
classes('43.4',	['1','43'],		['Verbs','of','substance','emission']).
classes('44',	['1','44'],		['Destroy']).
classes('45.1',	['1','45'],		['break','verbs']).
classes('45.2',	['1','45'],		['Bend','verbs']).
classes('45.3',	['1','45'],		['cooking','verbs']).
classes('45.4',	['1','45'],		['Other','Alternating','Verbs','of','Change','of','State','eg.blur','confuse','obscure','(','fig','change','of','state',')']).
classes('45.5',	['1','45'],		['Verbs','of','Entity','Specific','Change','of','State','restricting','these','verbs','to','physobj','may','be','a','mistake','but','all','Levins','verbs','seem','to','belong','in','that','class']).
classes('45.6',	['1','45'],		['Calibratable','changes','of','state']).
classes('46',	['1','46'],		['lodge','verbs']).
classes('47.1',	['1','47'],		['Exist','verbs','comment_1996_7_10','0',':','0',':','0','Diane']).
classes('47.2',	['1','47'],		['verbs','of','entity','-','specific','modes','of','being']).
classes('47.3',	['1','47'],		['Verbs','of','Modes','of','Being','Involving','Motion']).
classes('47.4',	['1','47'],		['Verbs','of','sound','existence','comment_1996_8_22','0',':','0',':','0','Diane']).
classes('47.5.1',['1','47'],		['Swarm']).
classes('47.5.2',['1','47'],		['Herd','Causative','use','left','to','individual','verbs']).
classes('47.6',	['1','47'],		['Verbs','of','Spatial','Configuration','Causative','left','for','specific','verbs']).
classes('47.7',	['1','47'],		['Meander','Path','can','be','expressed','in','various','ways','but','obligatory']).
classes('47.8',	['1','47'],		['Contiguous','Location']).
classes('48.1.1',['1','48'],		['Appear']).
classes('48.1.2',['1','48'],		['Reflexive','verbs','of','appearance']).
classes('48.2',	['1','48'],		['Verbs','of','disappearance','comment_1996_9_11','0',':','0',':','0','Diane']).
classes('48.3',	['1','48'],		['Verbs','of','occurrence','comment_1996_8_22','0',':','0',':','0','Diane']).
classes('49',	['1'],			['verbs','of','body','-','internal','motion','comment_1996_7_11','0',':','0',':','0','Diane']).
classes('50',	['1'],			['Verbs','of','Assuming','a','Position']).
classes('51.1',	['1','51'],		['Verbs','of','Inherently','Directed','Motion']).
classes('51.2',	['1','51'],		['Leave']).
classes('51.3.1',['1','51'],		['Roll']).
classes('51.3.2',['1','51'],		['Run','I','have','left','the','induced','action','alternation','and','locative','preposition','drop','alternation','for','individual','verbs','.','Measure','phrase','is','excluded','because','it','seems','generally','possible','with','any','movement','verb','and','not','specific','to','this','class','.','Locative','is','assumed','to','be','an','adjunct','when','it','is','a','PP','similarly','resultative']).
classes('51.4.1',['1','51'],		['Verbs','that','are','Vehicle','Names','As','with','51.3.2']).
classes('51.4.2',['1','51'],		['Verbs','that','are','not','Vehicle','Names','As','with','51.3.2']).
classes('51.5',	['1','51'],		['Waltz','As','with','51.3.2','plus','ignoring','cognate','obj']).
classes('51.6',	['1','51'],		['Chase','Intrans','uses','are','verb','specific']).
classes('51.7',	['1','51'],		['Accompany','verbs']).
classes('52',	['1','52'],		['Avoid','verbs','comment_1996_8_9','0',':','0',':','0','Diane']).
classes('53.1',	['1','53'],		['Verbs','of','lingering','comment_1996_8_19','0',':','0',':','0','Diane']).
classes('53.2',	['1','53'],		['Verbs','of','Rushing']).
classes('54.1',	['1','54'],		['Register','verbs','comment_1996_7_25','0',':','0',':','0','Diane']).
classes('54.2',	['1','54'],		['Cost','verbs','I','am','not','sure','about','the','theta','role','assignment','here','comment_1996_8_21','0',':','0',':','0','Diane']).
classes('54.3',	['1','54'],		['Fit','verbs']).
classes('54.4',	['1','54'],		['Price']).
classes('54.5',	['1','54'],		['Bill']).
classes('55.1',	['1','55'],		['Begin','verbs','comment_1996_8_16','0',':','0',':','0','Diane']).
classes('55.2',	['1','55'],		['Complete','verbs']).
classes('56',	['1','56'],		['Weekend','verbs','comment_1996_8_16','0',':','0',':','0','Diane']).
classes('57',	['1'],			['Weather','verbs','Pleonastic','it','subject']).
classes('8.2',	['0'],			['Obligatorily','reflexive','object','This','is','not','really','a','semantic','class','-','the','AGNT','and','THME','refer','to','the','same','entity']).
classes('9.1',	['1','9'],		['Put','PP','is','obligatory','at','least','for','put','-','therefore','treat','it','as','an','arg','for','current','purposes']).
classes('9.10',	['1','9'],		['Pocket','verbs']).
classes('9.2',	['1','9'],		['Verbs','of','putting','in','a','spatial','configuration']).
classes('9.3',	['1','9'],		['Funnel']).
classes('9.4',	['1','9'],		['Verbs','of','putting','with','a','specified','direction']).
classes('9.5',	['1','9'],		['Pour','verbs']).
classes('9.6',	['1','9'],		['Coil','See','also','51.3.1','for','intrans','uses']).
classes('9.7',	['1','9'],		['spray_load','verbs']).
classes('9.8',	['1','9'],		['Fill']).
classes('9.9',	['1','9'],		['Butter','verbs']).
classes('C1',	['0'],			['eg.argue','36.1','37.6']).
classes('C10',	['0'],			['23.2','45.1']).
                
                
                
                
                
                
                
                